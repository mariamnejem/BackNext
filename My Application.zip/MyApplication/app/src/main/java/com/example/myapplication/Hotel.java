package com.example.myapplication;

public class Hotel {
    private String name;
    private String stars;
}
